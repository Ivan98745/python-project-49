### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ivan98745/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ivan98745/python-project-49/actions)
[Presentation of the Parity Check game](https://asciinema.org/a/Ov1vztrlUHu3k6oiNVT48kBrO)
