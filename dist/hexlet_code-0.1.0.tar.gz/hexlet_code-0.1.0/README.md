### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ivan98745/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ivan98745/python-project-49/actions)
[Presentation of the Parity Check game](https://asciinema.org/a/Ov1vztrlUHu3k6oiNVT48kBrO)
[Presentation of the Calculator game](https://asciinema.org/a/1pc9bS9diAtuTf27nbi8Jg3ad)
[Presentation of the Greatest Common Divisor game](https://asciinema.org/a/LLtDcpuhISW3xR138McfSpvln)
